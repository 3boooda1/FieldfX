// Vercel Function: reads ONE pixel from NASA LP DAAC cloud-optimised GeoTIFFs (HTTP range requests, no full downloads).
//   ?src=eco -> ECOSTRESS ECO_L2T_LSTE v002 land-surface temperature (70 m)
//   ?src=hls -> Landsat 8/9 via HLSL30 v2.0 (30 m), NDVI computed from B04/B05
// Needs EARTHDATA_TOKEN. Add &debug=1 to see which granules/URLs/errors came back.
import {fromUrl} from 'geotiff'
import proj4 from 'proj4'
const CMR='https://cmr.earthdata.nasa.gov/search/granules.json'
const tileOf=id=>{const m=/(?:_|\.T)(\d{2})([C-X])[A-Z]{2}(?:_|\.)/.exec(id||'');return m?{zone:+m[1],south:m[2]<'N'}:null}
async function px(url,lat,lon,H,tile){
  const img=await (await fromUrl(url,{headers:H,allowFullFile:false})).getImage(),code=img.getGeoKeys().ProjectedCSTypeGeoKey
  let zone,south
  if(code>=32601&&code<=32660){zone=code-32600;south=false}else if(code>=32701&&code<=32760){zone=code-32700;south=true}else if(tile){zone=tile.zone;south=tile.south}else throw new Error('unknown CRS '+code+' in '+url.slice(-30))
  const def=`+proj=utm +zone=${zone} ${south?'+south ':''}+datum=WGS84 +units=m +no_defs`
  const [x,y]=proj4('EPSG:4326',def,[lon,lat]),[ox,oy]=img.getOrigin(),[rx,ry]=img.getResolution()
  if(![x,y,ox,oy,rx,ry].every(Number.isFinite))throw new Error('bad geometry '+JSON.stringify({code,zone,x,y,ox,oy,rx,ry}))
  const c=Math.floor((x-ox)/rx),r=Math.floor((y-oy)/ry),w=img.getWidth(),h=img.getHeight()
  const info={code,zone,c,r,w,h,x:Math.round(x),y:Math.round(y),ox,oy,rx,ry,nodata:img.getGDALNoData()}
  if(c<0||r<0||c>=w||r>=h)return {v:null,oob:true,info}
  const v=(await img.readRasters({window:[c,r,c+1,r+1]}))[0][0]
  return {v:Number.isFinite(v)?v:null,rawv:String(v),info}
}
const link=(g,re)=>((g.links||[]).find(l=>re.test(l.href||'')&&/^https:/.test(l.href))||{}).href
export default async function handler(req,res){
  const lat=parseFloat(req.query.lat),lon=parseFloat(req.query.lon),src=req.query.src,debug=!!req.query.debug,tok=process.env.EARTHDATA_TOKEN
  if(!isFinite(lat)||!isFinite(lon)||!['eco','hls'].includes(src))return res.status(400).json({error:'lat, lon, src=eco|hls required'})
  if(!tok)return res.status(503).json({error:'EARTHDATA_TOKEN missing'})
  const H={Authorization:'Bearer '+tok},eco=src==='eco',log=[]
  try{
    const q=eco?'short_name=ECO_L2T_LSTE&version=002':'short_name=HLSL30&version=2.0'
    const g=((await (await fetch(`${CMR}?${q}&point=${lon},${lat}&sort_key=-start_date&page_size=${eco?20:10}`)).json()).feed.entry)||[]
    const out=await Promise.all(g.map(async e=>{try{
      let v=null,raw=null
      if(eco){const t=link(e,/_LST\.tif$/),cl=link(e,/_cloud\.tif$/),tl=tileOf(e.producer_granule_id||e.title);if(!t)return null
        const [K,C]=await Promise.all([px(t,lat,lon,H,tl),cl?px(cl,lat,lon,H,tl):{v:0}]),k=K.v,c=C.v;raw={k:K.rawv,c:C.rawv,oob:!!K.oob,ki:K.info};let kk=k;if(kk>5000&&kk<30000)kk=kk*0.02;if(kk!=null&&kk>150&&kk<400&&c!==1)v=kk-273.15}
      else{const b4=link(e,/\.B04\.tif$/),b5=link(e,/\.B05\.tif$/),fm=link(e,/\.Fmask\.tif$/),tl=tileOf(e.producer_granule_id||e.title);if(!b4||!b5)return null
        const [R,N,F]=await Promise.all([px(b4,lat,lon,H,tl),px(b5,lat,lon,H,tl),fm?px(fm,lat,lon,H,tl):{v:0}]),r=R.v,n=N.v,f=F.v
        if(r!=null&&n!=null&&r>-9999&&n>-9999&&r+n>0&&(f&14)===0)v=(n-r)/(n+r)}
      if(debug)log.push({id:e.producer_granule_id,v,raw});return v==null?null:[e.time_start.slice(0,10),v]}catch(err){if(debug)log.push({id:e.producer_granule_id,err:String(err.message||err)});return null}}))
    if(debug)return res.status(200).json({found:g.length,log})
    const s=out.filter(Boolean).sort((a,b)=>a[0]<b[0]?-1:1);if(!s.length)throw new Error('no clear-sky pixels in recent granules (try ?debug=1)')
    const v=s.map(x=>x[1])
    res.setHeader('Cache-Control','s-maxage=21600, stale-while-revalidate')
    res.status(200).json({mean:v.reduce((a,b)=>a+b,0)/v.length,min:Math.min(...v),max:Math.max(...v),n:v.length,series:s,source:eco?'NASA ECOSTRESS ECO_L2T_LSTE v002':'Landsat 8/9 HLSL30 v2.0 (NDVI)'})
  }catch(err){res.status(502).json({error:String(err.message||err)})}
}
