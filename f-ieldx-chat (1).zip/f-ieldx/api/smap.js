// Vercel Function: SMAP L3 Enhanced (SPL3SMP_E v006, 9 km) surface soil moisture for one point.
// Uses OPeNDAP (Hyrax) to read ONE grid cell per granule instead of downloading 240 MB files.
// Needs env var EARTHDATA_TOKEN. Add ?debug=1 to see the raw server reply when something fails.
const CMR='https://cmr.earthdata.nasa.gov/search/granules.json?short_name=SPL3SMP_E&version=006&sort_key=-start_date&page_size=12'
const A=6378137,E2=0.00669437999014,E=Math.sqrt(E2),K0=Math.cos(Math.PI/6)/Math.sqrt(1-E2*.25),RES=9008.055210146
const q=s=>(1-E2)*(s/(1-E2*s*s)-Math.log((1-E*s)/(1+E*s))/(2*E))
function cell(lat,lon){const x=A*K0*lon*Math.PI/180,y=A*q(Math.sin(lat*Math.PI/180))/(2*K0)
  return [Math.min(1623,Math.max(0,Math.floor((7314540.83-y)/RES))),Math.min(3855,Math.max(0,Math.floor((x+17367530.445)/RES)))]}
export default async function handler(req,res){
  const lat=parseFloat(req.query.lat),lon=parseFloat(req.query.lon),debug=!!req.query.debug,tok=process.env.EARTHDATA_TOKEN
  if(!isFinite(lat)||!isFinite(lon))return res.status(400).json({error:'lat/lon required'})
  if(!tok)return res.status(503).json({error:'EARTHDATA_TOKEN missing'})
  try{
    const [r,c]=cell(lat,lon),H={Authorization:'Bearer '+tok}
    const g=(await (await fetch(CMR)).json()).feed.entry||[],raw=[]
    const out=await Promise.all(g.map(async e=>{
      const l=(e.links||[]).find(x=>/OPeNDAP/i.test(x.title||''));if(!l)return null
      const r0=Math.max(0,r-2),r1=Math.min(1623,r+2),c0=Math.max(0,c-2),c1=Math.min(3855,c+2)
      const ce=encodeURIComponent(`/Soil_Moisture_Retrieval_Data_AM/soil_moisture[${r0}:${r1}][${c0}:${c1}]`)
      const resp=await fetch(`${l.href}.dap.csv?dap4.ce=${ce}`,{headers:H}),txt=await resp.text()
      if(debug&&raw.length<2)raw.push({status:resp.status,len:txt.length,text:txt.slice(0,1500)})
      if(!resp.ok)return null
      const nums=txt.split(/\r?\n/).slice(1).flatMap(line=>line.replace(/^[^,]*\[[^\]]*\][^,]*,/,'').split(/[,\s]+/)).map(parseFloat).filter(x=>isFinite(x)&&x>0&&x<=1).sort((x,y)=>x-y)
      return nums.length?[e.time_start.slice(0,10),nums[Math.floor(nums.length/2)]]:null}))
    if(debug)return res.status(200).json({cell:[r,c],raw})
    const seen=new Set(),s=out.filter(Boolean).sort((a,b)=>a[0]<b[0]?-1:1).filter(x=>!seen.has(x[0])&&seen.add(x[0]));if(!s.length)throw new Error('no valid SMAP cells (try ?debug=1)')
    const v=s.map(x=>x[1])
    res.setHeader('Cache-Control','s-maxage=21600, stale-while-revalidate')
    res.status(200).json({mean:v.reduce((a,b)=>a+b,0)/v.length,min:Math.min(...v),max:Math.max(...v),n:v.length,series:s,source:'NASA SMAP L3 SPL3SMP_E v006'})
  }catch(err){res.status(502).json({error:String(err.message||err)})}
}
