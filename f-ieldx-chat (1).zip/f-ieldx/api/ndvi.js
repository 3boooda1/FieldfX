// Vercel Function: MODIS NDVI (MOD13Q1, 250 m, 16-day) for one point, via ORNL DAAC web service.
// Runs on the server so the browser never hits CORS limits. EARTHDATA_TOKEN is read here for future SMAP calls.
const BASE='https://modis.ornl.gov/rst/api/v1/MOD13Q1/subset'
const RANGES=[['A2024001','A2024128'],['A2024129','A2024256'],['A2024257','A2024366']]
export default async function handler(req,res){
  const lat=parseFloat(req.query.lat),lon=parseFloat(req.query.lon)
  if(!isFinite(lat)||!isFinite(lon))return res.status(400).json({error:'lat/lon required'})
  try{
    const parts=await Promise.all(RANGES.map(async([a,b])=>{
      const r=await fetch(`${BASE}?latitude=${lat.toFixed(4)}&longitude=${lon.toFixed(4)}&band=250m_16_days_NDVI&startDate=${a}&endDate=${b}&kmAboveBelow=0&kmLeftRight=0`,{headers:{Accept:'application/json'}})
      if(!r.ok)throw new Error('ORNL '+r.status);return (await r.json()).subset||[]}))
    const S=Array.from({length:12},()=>[]);let n=0
    parts.flat().forEach(o=>{const v=(o.data||[])[0],m=new Date(o.calendar_date).getUTCMonth();if(v!=null&&v>-1000&&isFinite(m)){S[m].push(v*0.0001);n++}})
    if(!n)throw new Error('no data')
    res.setHeader('Cache-Control','s-maxage=86400, stale-while-revalidate')
    res.status(200).json({monthly:S.map(a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:null),n,source:'MODIS MOD13Q1 NDVI via ORNL DAAC',year:2024})
  }catch(e){res.status(502).json({error:String(e.message||e)})}
}
