import {CROPS} from './data.js'
import {score,NEED} from './engine.js'
const FAM={wheat:'c',barley:'c',maize:'c',rice:'c',sorghum:'c',millet:'c',cotton:'f',sunflower:'o',lentil:'l',chickpea:'l',soybean:'l',alfalfa:'l'}
const SEAS={wheat:'w',barley:'w',lentil:'w',chickpea:'w',maize:'s',rice:'s',sorghum:'s',millet:'s',cotton:'s',sunflower:'s',soybean:'s',alfalfa:'p'}
const SM={w:[10,11,0,1,2,3,4],s:[4,5,6,7,8,9],p:[0,1,2,3,4,5,6,7,8,9,10,11]}
const clamp=x=>Math.max(0,Math.min(100,x))
export const simulate=(cl,s)=>!s||(!s.rain&&!s.temp)?cl:{...cl,rain:cl.rain*(1+s.rain/100),monthly:cl.monthly.map(m=>m*(1+s.rain/100)),tmax:cl.tmax+s.temp,tmin:cl.tmin+s.temp,hotDays:cl.hotDays!=null?cl.hotDays+6*s.temp:undefined,frostDays:cl.frostDays!=null?Math.max(0,cl.frostDays-5*s.temp):undefined,et0:cl.et0?cl.et0*(1+.04*s.temp):cl.et0}
function order(seq){let bonus=0;const notes=new Set();seq.forEach((c,i)=>{const p=seq[(i+seq.length-1)%seq.length];if(c===p){bonus-=10;notes.add('o_same')}else if(FAM[c]===FAM[p]&&FAM[c]!=='l'){bonus-=5;notes.add('o_fam')}else if(FAM[p]==='l'&&FAM[c]!=='l'){bonus+=6;notes.add('o_n')}});return {bonus,notes:[...notes]}}
const labAdj=c=>{let a=0;const om=parseFloat(c.om),ph=parseFloat(c.ph),ec=parseFloat(c.ec);if(!isNaN(om))a+=om<1.5?-10:om>=3?8:0;if(!isNaN(ph))a+=(ph<5.5||ph>8.2)?-8:(ph>=6&&ph<=7.5)?3:0;if(!isNaN(ec))a+=ec>4?-12:ec>2?-5:0;return a}
const cal=(seq,mo,south)=>seq.map(c=>{const on=new Set(SM[SEAS[c]].map(m=>(m+(south?6:0))%12));return mo.map((r,m)=>on.has(m)?'c':r>=25?'v':'b')})
function build(k,seq,cl,pr,cfg,south,why){
  const s=score(seq,cl,pr,cfg),o=order(seq),adj=labAdj(cfg),sum=(pr.water+pr.soil+pr.climate+(pr.market||0)+(pr.ops||0))||1,avg=x=>seq.reduce((a,c)=>a+CROPS[c][x],0)/seq.length
  const need=Math.round(seq.reduce((a,c)=>a+NEED[CROPS[c].w],0)/seq.length),cl2=cal(seq,cl.monthly,south),bare=cl2.flat().filter(x=>x!=='c').length
  const ev=[['ev_rain',{r:Math.round(cl.rain),n:need},'NASA POWER (GPM IMERG)']];if(cl.hotDays!=null)ev.push(['ev_hot',{d:cl.hotDays.toFixed(0)},'ERA5*']);if(cl.frostDays!=null)ev.push(['ev_frost',{d:cl.frostDays.toFixed(0)},'ERA5*']);if(cl.ndvi){const v=cl.ndvi.filter(x=>x!=null);ev.push(['ev_ndvi',{v:(v.reduce((a,b)=>a+b,0)/v.length).toFixed(2),b:cl.ndvi.filter(x=>x!=null&&x<.25).length},'NASA MODIS NDVI'])}
  if(cl.slope!=null)ev.push(['ev_slope',{s:cl.slope.toFixed(0)},'SRTM'])
  const sm=cl.smap?Math.max(-8,Math.min(8,(cl.smap.mean-.2)*60))*[1,.65,.3][cfg.irr||0]:0
  if(cl.smap)ev.push(['ev_smap',{v:cl.smap.mean.toFixed(2),n:cl.smap.n},'NASA SMAP'])
  if(cl.eco)ev.push(['ev_eco',{t:cl.eco.mean.toFixed(0),x:cl.eco.max.toFixed(0)},'NASA ECOSTRESS'])
  if(cl.hls)ev.push(['ev_hls',{v:cl.hls.mean.toFixed(2),n:cl.hls.n},'Landsat 8/9 (HLS, 30 m)'])
  const lab=['om','ph','ec'].some(x=>cfg[x]!==''&&cfg[x]!=null)
  return {...s,k,seq,ids:[seq[0],seq[1]],soil:Math.round(clamp(s.soil+adj)),water:Math.round(clamp(s.water+sm)),total:Math.round(clamp(s.total+(pr.soil*adj+pr.water*sm)/sum+o.bonus)),why:[...why,...o.notes],ev,cal:cl2,labs:lab,conf:lab?cl.conf:(cl.conf==='h'?'m':cl.conf),om:.012*(3*avg('N')+avg('r'))-.04*bare/48-(cl.slope>8?.02:0)}
}
export function planAll(cur,cl,pr,cfg,south){
  const [a,b]=cur,L=['lentil','chickpea','soybean','alfalfa'],lean=['sorghum','millet','barley','chickpea','sunflower'],perms=[]
  lean.forEach(p=>lean.forEach(q=>lean.forEach(r=>lean.forEach(u=>{if(new Set([p,q,r,u]).size===4)perms.push([p,q,r,u])}))))
  const B=(ws,k,why)=>ws.map(w=>build(k,w,cl,pr,cfg,south,why)).sort((x,y)=>y.total-x.total)[0]
  return [build('s_cur',a===b?[a,a,a,a]:[a,b,a,b],cl,pr,cfg,south,['why_cur']),B(L.map(l=>[a,l,b,l]),'s_leg',['why_fix']),B(perms,'s_dry',['why_lean'])]
}
