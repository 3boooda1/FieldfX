import {useEffect,useState} from 'react'
import {flushSync} from 'react-dom'
import gsap from 'gsap'
import {ScrollTrigger} from 'gsap/ScrollTrigger'
import Lenis from 'lenis'
gsap.registerPlugin(ScrollTrigger)
export const calm=()=>matchMedia('(prefers-reduced-motion: reduce)').matches
const AG='ابتثجحخدذرزسشصضطظعغفقكلمنهوي',LG='ABCDEFGHJKLMNPQRSTUVWXYZ#%&@*+<>/',AR=/[\u0600-\u06FF]/,KEEP=/[\s.,:;·()\-–—/%°{}\d]/,st=new WeakMap()
export function scrambleTo(node,to,dur=650){
  const o=st.get(node);if(o)cancelAnimationFrame(o.raf)
  const n=to.length,dl=Array.from({length:n},(_,i)=>i/n*dur*.65+Math.random()*dur*.3),t0=performance.now(),s={raf:0,last:to};st.set(node,s)
  const step=now=>{const t=now-t0;let out='',done=true
    for(let i=0;i<n;i++){const c=to[i];if(t>=dl[i]+dur*.18||KEEP.test(c))out+=c;else{done=false;const g=AR.test(c)?AG:LG;out+=g[Math.random()*g.length|0]}}
    s.last=out;node.data=out;if(!done)s.raf=requestAnimationFrame(step);else{s.last=to;node.data=to}}
  s.raf=requestAnimationFrame(step)
}
let armed=false
export const armGlitch=(ms=1700)=>{armed=true;setTimeout(()=>{armed=false},ms)}
function glitchAll(){
  new MutationObserver(ms=>{if(!armed)return;for(const m of ms){const nd=m.target;if(nd.nodeType!==3)continue;const s=st.get(nd);if(s&&nd.data===s.last)continue
    const to=nd.data;if(to===m.oldValue||!/\p{L}/u.test(to)||nd.parentElement?.closest('option,script,style,textarea'))continue;scrambleTo(nd,to)}})
  .observe(document.body,{characterData:true,subtree:true,characterDataOldValue:true})
}
export function vt(fn,e){
  if(!document.startViewTransition||calm()){fn();return}
  const r=document.documentElement.style;r.setProperty('--vx',(e&&e.clientX!=null?e.clientX:innerWidth/2)+'px');r.setProperty('--vy',(e&&e.clientY!=null?e.clientY:innerHeight/2)+'px')
  document.startViewTransition(()=>flushSync(fn))
}
export function initFx(){
  if(calm())return
  glitchAll()
  if(matchMedia('(pointer:fine)').matches){
    addEventListener('pointermove',e=>{const b=e.target.closest&&e.target.closest('.btn');if(!b)return;const r=b.getBoundingClientRect();b.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.22}px,${(e.clientY-r.top-r.height/2)*.32}px)`})
    addEventListener('pointerout',e=>{const b=e.target.closest&&e.target.closest('.btn');if(b)b.style.transform=''})
  }
  const l=new Lenis({lerp:.09});l.on('scroll',ScrollTrigger.update);gsap.ticker.add(t=>l.raf(t*1000));gsap.ticker.lagSmoothing(0)
}
export function Num({v,d=0}){
  const [x,setX]=useState(calm()?v:0)
  useEffect(()=>{if(calm()){setX(v);return}let raf;const t0=performance.now(),f=n=>{const k=Math.min(1,(n-t0)/1300);setX(v*(1-Math.pow(1-k,4)));if(k<1)raf=requestAnimationFrame(f)};raf=requestAnimationFrame(f);return()=>cancelAnimationFrame(raf)},[v])
  return <>{x.toFixed(d)}</>
}
export function Ring({v,size=64}){
  const [p,setP]=useState(0);useEffect(()=>{const id=setTimeout(()=>setP(v),90);return()=>clearTimeout(id)},[v])
  const r=26,c=2*Math.PI*r
  return <svg className="ring" viewBox="0 0 64 64" width={size} height={size} aria-label={v+'/100'}><circle cx="32" cy="32" r={r} className="rb"/><circle cx="32" cy="32" r={r} className="rf" strokeDasharray={c} strokeDashoffset={c*(1-p/100)} transform="rotate(-90 32 32)"/><text x="32" y="37" textAnchor="middle">{v}</text></svg>
}
export {gsap}
