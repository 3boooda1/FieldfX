import {CROPS} from './data.js'
export const NEED={1:400,2:650,3:950} // rough seasonal water need (mm) per demand class
const MK={wheat:2,barley:1,maize:3,rice:2,sorghum:1,millet:1,cotton:3,sunflower:2,lentil:2,chickpea:3,soybean:3,alfalfa:2},OP={wheat:3,barley:3,maize:2,rice:1,sorghum:3,millet:3,cotton:1,sunflower:2,lentil:2,chickpea:3,soybean:2,alfalfa:2}
const IRR={0:1,1:.65,2:.3},TEX={sand:[-8,-6],loam:[4,0],clay:[2,4]}
export function score(ids,cl,pr,cfg={tex:'loam',irr:0}){
  const cs=ids.map(i=>CROPS[i]),avg=k=>cs.reduce((a,c)=>a+c[k],0)/cs.length
  const deficit=cs.reduce((a,c)=>a+Math.max(0,(NEED[c.w]-cl.rain)/NEED[c.w]),0)/cs.length*IRR[cfg.irr]
  const heat=cl.hotDays!=null?Math.min(1,cl.hotDays/45)*(3-avg('h'))/2:(cl.tmax>32?Math.min(1,(cl.tmax-32)/8)*(3-avg('h'))/2:0)
  const frost=cl.frostDays!=null?Math.min(1,cl.frostDays/60)*(3-avg('f'))/2:(cl.tmin<3?Math.min(1,(3-cl.tmin)/10)*(3-avg('f'))/2:0)
  const eros=cl.slope!=null?Math.min(1,cl.slope/12)*Math.min(1,(cl.heavy||3)/8):0
  const div=new Set(ids).size/ids.length
  const water=Math.max(0,Math.min(100,100*(1-deficit)+TEX[cfg.tex][1])),climate=100*(1-Math.min(1,heat+frost)),soil=Math.max(0,TEX[cfg.tex][0]+20+40*avg('N')+20*avg('r')/3+20*div-25*eros*(1-avg('r')/3))
  const mkt=Math.round(ids.reduce((a,i)=>a+MK[i],0)/ids.length/3*100),ops=Math.round(ids.reduce((a,i)=>a+OP[i],0)/ids.length/3*100),sum=(pr.water+pr.soil+pr.climate+(pr.market||0)+(pr.ops||0))||1
  const flags=[deficit>0.25?['waterLow',{r:Math.round(cl.rain)}]:['waterOk',{r:Math.round(cl.rain)}]]
  if(cl.et0&&cl.rain/cl.et0<.5)flags.push(['arid',{r:Math.round(100*cl.rain/cl.et0)}]);if(eros>.25&&avg('r')<2.5)flags.push(['erosion',{s:cl.slope.toFixed(0)}]);if(avg('N')>0)flags.push(['fixer',{}]); if(div<1)flags.push(['mono',{}])
  if(frost>0.15)flags.push(['frostRisk',{t:cl.tmin.toFixed(0)}]); if(heat>0.15)flags.push(['heatRisk',{t:cl.tmax.toFixed(0)}])
  const ben=[];if(avg('N')>0)ben.push('ben_fix');if(avg('w')<=1.5)ben.push('ben_lean');if(avg('r')>=2.5)ben.push('ben_root');if(div===1&&ids.length>1)ben.push('ben_div')
  return {ids,flags,ben,water:Math.round(water),climate:Math.round(climate),soil:Math.round(soil),mkt,ops,total:Math.round((pr.water*water+pr.soil*soil+pr.climate*climate+(pr.market||0)*mkt+(pr.ops||0)*ops)/sum)}
}
const best=(sets,cl,pr,cfg)=>sets.map(s=>score(s,cl,pr,cfg)).sort((a,b)=>b.total-a.total)[0]
export function compare(cur,cl,pr,cfg){
  const legumes=['lentil','chickpea','soybean','alfalfa'],lean=['sorghum','millet','barley','chickpea','sunflower']
  const pairs=[];lean.forEach(a=>lean.forEach(b=>{if(a<b)pairs.push([a,b])}))
  return [{k:'s_cur',...score(cur,cl,pr,cfg)},
   {k:'s_leg',...best(legumes.map(l=>[cur[0],l]),cl,pr,cfg)},
   {k:'s_dry',...best(pairs,cl,pr,cfg)}]
}
