// Tiny shared store: the Tool publishes the selected land + results here, the chat widget reads it.
let s=null;const subs=new Set()
export const setFx=v=>{s=v;subs.forEach(f=>f())}
export const getFx=()=>s
export const subFx=f=>{subs.add(f);return()=>subs.delete(f)}
