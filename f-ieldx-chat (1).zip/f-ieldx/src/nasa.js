const URL_='https://power.larc.nasa.gov/api/temporal/climatology/point'
const M=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'],D=[31,28,31,30,31,30,31,31,30,31,30,31]
async function getPower(lat,lon){
  const u=`${URL_}?parameters=T2M_MAX,T2M_MIN,PRECTOTCORR&community=AG&longitude=${lon.toFixed(3)}&latitude=${lat.toFixed(3)}&format=JSON`
  const r=await fetch(u); if(!r.ok) throw new Error('POWER '+r.status)
  const p=(await r.json()).properties.parameter
  const a=k=>M.map(m=>p[k][m])
  const mx=a('T2M_MAX'),mn=a('T2M_MIN'),pr=a('PRECTOTCORR').map((v,i)=>Math.max(0,v)*D[i])
  return {rain:pr.reduce((s,v)=>s+v,0),tmax:Math.max(...mx),tmin:Math.min(...mn),monthly:pr,dry:pr.filter(v=>v<30).length}
}
async function areaPts(pts){
  const r=(await Promise.allSettled(pts.map(([a,o])=>getPower(Math.max(-89,Math.min(89,a)),o)))).filter(x=>x.status==='fulfilled').map(x=>x.value);if(!r.length)throw new Error('POWER')
  const av=k=>r.reduce((s,x)=>s+x[k],0)/r.length,sd=k=>{const m=av(k);return Math.sqrt(r.reduce((s,x)=>s+(x[k]-m)**2,0)/r.length)}
  return {rain:av('rain'),tmax:av('tmax'),tmin:av('tmin'),dry:Math.round(av('dry')),monthly:r[0].monthly.map((_,i)=>r.reduce((s,x)=>s+x.monthly[i],0)/r.length),rainMin:Math.min(...r.map(x=>x.rain)),rainMax:Math.max(...r.map(x=>x.rain)),rainSd:sd('rain'),n:r.length}
}
export async function geocode(q,lang){
  const r=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=6&language=${lang}`),j=await r.json()
  return (j.results||[]).map(x=>({name:[x.name,x.admin1,x.country].filter(Boolean).join(', '),lat:x.latitude,lon:x.longitude,code:x.feature_code||''}))
}
const safe=async f=>{try{return await f()}catch{return {}}}
async function soilSolar(lat,lon){
  const r=await fetch(`${URL_}?parameters=GWETROOT,GWETTOP,ALLSKY_SFC_SW_DWN&community=AG&longitude=${lon.toFixed(3)}&latitude=${lat.toFixed(3)}&format=JSON`);if(!r.ok)throw 0
  const p=(await r.json()).properties.parameter,a=k=>p[k].ANN>=0?p[k].ANN:null
  return {soilRoot:a('GWETROOT'),soilTop:a('GWETTOP'),solar:a('ALLSKY_SFC_SW_DWN')}
}
async function era5(lat,lon){
  const r=await fetch(`https://archive-api.open-meteo.com/v1/archive?latitude=${lat.toFixed(3)}&longitude=${lon.toFixed(3)}&start_date=2005-01-01&end_date=2024-12-31&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,et0_fao_evapotranspiration&timezone=UTC`)
  if(!r.ok)throw 0;const j=(await r.json()).daily;let fr=0,hot=0,hv=0,mx=0,et=0,rA=0,rB=0,tA=0,tB=0,nA=0,nB=0;const Y={}
  for(let i=0;i<j.time.length;i++){const a=j.temperature_2m_max[i],b=j.temperature_2m_min[i],p=j.precipitation_sum[i]||0;if(a==null||b==null)continue
    const y=+j.time[i].slice(0,4);(Y[y]=Y[y]||[0,0]);Y[y][0]+=(a+b)/2;Y[y][1]++
    if(b<0)fr++;if(a>35)hot++;if(p>=20)hv++;if(p>mx)mx=p;et+=j.et0_fao_evapotranspiration[i]||0
    if(y>=2020){rB+=p;tB+=(a+b)/2;nB++}else if(y>=2015){rA+=p;tA+=(a+b)/2;nA++}}
  return {frostDays:fr/20,hotDays:hot/20,heavy:hv/20,maxDay:mx,et0:et/20,trendRain:(rB-rA)/5,trendTemp:tB/(nB||1)-tA/(nA||1),yearT:Object.keys(Y).sort().map(k=>Y[k][0]/Y[k][1])}
}
async function srtm(lat,lon){
  const d=.0009,L=[[lat,lon],[lat+d,lon],[lat,lon+d]].map(p=>p.map(v=>v.toFixed(5)).join(',')).join('|')
  const j=await (await fetch('https://api.opentopodata.org/v1/srtm30m?locations='+L)).json(),e=j.results.map(x=>x.elevation);if(e.some(v=>v==null))throw 0
  const m=d*111320,dx=(e[2]-e[0])/(m*Math.cos(lat*Math.PI/180)),dy=(e[1]-e[0])/m
  return {elev:e[0],slope:Math.sqrt(dx*dx+dy*dy)*100}
}
const extras=async(lat,lon)=>Object.assign({},...await Promise.all([safe(()=>soilSolar(lat,lon)),safe(()=>era5(lat,lon)),safe(()=>srtm(lat,lon)),safe(async()=>{const r=await fetch(`/api/ndvi?lat=${lat.toFixed(4)}&lon=${lon.toFixed(4)}`);if(!r.ok)throw 0;const j=await r.json();return {ndvi:j.monthly}}),safe(async()=>{const r=await fetch(`/api/smap?lat=${lat.toFixed(4)}&lon=${lon.toFixed(4)}`);if(!r.ok)throw 0;return {smap:await r.json()}}),safe(async()=>{const r=await fetch(`/api/cog?src=eco&lat=${lat.toFixed(4)}&lon=${lon.toFixed(4)}`);if(!r.ok)throw 0;return {eco:await r.json()}}),safe(async()=>{const r=await fetch(`/api/cog?src=hls&lat=${lat.toFixed(4)}&lon=${lon.toFixed(4)}`);if(!r.ok)throw 0;return {hls:await r.json()}})]))
export async function getPoints(pts){const [p,x]=await Promise.all([areaPts(pts),extras(pts[0][0],pts[0][1])]);const ok=['yearT','elev','soilRoot','ndvi','smap'].filter(k=>x[k]!=null).length,sp=p.rain?p.rainSd/p.rain:0
  return {...p,...x,conf:ok>=3&&sp<.15?'h':ok>=2&&sp<.3?'m':'l'}}

// Real outline of the picked place (country / region / city) from OpenStreetMap Nominatim.
// Falls back to the analysis square (±0.2°) when the place only exists as a point.
export async function boundary(lat,lon,code=''){
  const z=/^PCL/.test(code)?3:code==='ADM1'?5:code==='ADM2'?8:10
  const r=await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&zoom=${z}&format=jsonv2&polygon_geojson=1&polygon_threshold=0.01`)
  if(!r.ok)throw new Error('boundary '+r.status)
  const j=await r.json()
  return {geo:j.geojson&&/Polygon/.test(j.geojson.type)?j.geojson:null}
}
