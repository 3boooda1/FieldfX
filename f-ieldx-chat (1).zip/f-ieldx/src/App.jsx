import {useEffect,useRef,useState} from 'react'
import Tool from './Tool.jsx'
import Chat from './Chat.jsx'
import {DIA,LANGS,getT} from './data.js'
import {flushSync} from 'react-dom'
import {gsap,vt,calm,armGlitch} from './fx.jsx'
import {ScrollTrigger} from 'gsap/ScrollTrigger'
const MQ=['NASA POWER','SMAP','GPM IMERG','MODIS','SRTM','ECOSTRESS','ERA5','FAO GAEZ','Landsat','Sentinel-2']
function Home({t,go}){
  const root=useRef(),vid=useRef()
  useEffect(()=>{
    if(calm())return
    const v=vid.current,ctx=gsap.context(()=>{
      v.pause()
      const set=()=>{const d=v.duration||15;ScrollTrigger.create({trigger:'.space',start:'top top',end:'bottom bottom',scrub:.5,onUpdate:s=>{const x=s.progress*(d-.3);if(!v.seeking&&Math.abs(v.currentTime-x)>.03)v.currentTime=x}})}
      v.readyState>0?set():v.addEventListener('loadedmetadata',set,{once:true})
      gsap.to('.pin .hcopy',{opacity:0,y:-70,scrollTrigger:{trigger:'.space',start:'top top',end:'+=30%',scrub:true}})
      gsap.from('.hcopy>*',{y:50,opacity:0,duration:1.1,ease:'power4.out',stagger:.15,delay:.3})
      gsap.utils.toArray('.rows>div').forEach(el=>{
        gsap.from(el,{opacity:0,y:90,duration:1.1,ease:'power3.out',scrollTrigger:{trigger:el,start:'top 88%'}})
        gsap.from(el.querySelector('.no'),{xPercent:-60,opacity:0,scrollTrigger:{trigger:el,start:'top 95%',end:'top 55%',scrub:true}})})
      gsap.from('.cta h2',{y:80,opacity:0,duration:1.2,ease:'power4.out',scrollTrigger:{trigger:'.cta',start:'top 80%'}})
    },root)
    return()=>ctx.revert()
  },[])
  return <div ref={root}>
    <section className="space"><div className="pin"><video ref={vid} src="/earth.mp4" poster="/earth.jpg" muted playsInline preload="auto" aria-hidden="true"/><div className="hcopy"><h1>{t.h1}</h1><p>{t.sub}</p><a className="btn" href="#tool" onClick={e=>go(e,'tool')}>{t.cta}</a></div></div></section>
    <div className="after"><div className="marq" aria-hidden="true"><div>{[...MQ,...MQ,...MQ,...MQ].map((m,i)=><span key={i}>{m}</span>)}</div></div>
    <div className="rows">{[['f1','f1d'],['f2','f2d'],['f3','f3d']].map(([a,b],i)=><div key={a}><span className="no">0{i+1}</span><h3>{t[a]}</h3><p>{t[b]}</p></div>)}</div>
    <section className="cta"><h2>{t.where}</h2><a className="btn" href="#tool" onClick={e=>go(e,'tool')}>{t.cta}</a></section></div></div>
}
export default function App(){
  const [route,setRoute]=useState(location.hash.slice(1)||'home'),[lang,setLang]=useState('en'),[theme,setTheme]=useState(()=>localStorage.getItem('fx-theme')||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light')),[dia,setDia]=useState('us'),t=getT(lang,dia)
  useEffect(()=>{const f=()=>setRoute(location.hash.slice(1)||'home');addEventListener('hashchange',f);addEventListener('popstate',f);return()=>{removeEventListener('hashchange',f);removeEventListener('popstate',f)}},[])
  useEffect(()=>{document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr'},[lang])
  useEffect(()=>{scrollTo(0,0)},[route])
  useEffect(()=>{document.documentElement.dataset.theme=theme;try{localStorage.setItem('fx-theme',theme)}catch{}},[theme])
  const changeLang=(l,d)=>{const apply=()=>{const nl=l||lang,nd=d||(l?Object.keys(DIA[l]||{})[0]||'':dia);document.documentElement.lang=nl;document.documentElement.dir=nl==='ar'?'rtl':'ltr';if(l)setLang(l);setDia(nd)}
    if(calm()||!document.startViewTransition){apply();return}
    armGlitch();const h=document.documentElement;h.classList.add('langfade');document.startViewTransition(()=>flushSync(apply)).finished.finally(()=>h.classList.remove('langfade'))}
  const go=(e,k)=>{e.preventDefault();if(k===route)return;vt(()=>{setRoute(k);history.pushState(null,'','#'+k)},e)}
  const nav=[['home',t.home],['tool',t.tool],['method',t.method]]
  const live=['pow','m_era','m_srtm','m_gibs','m_soil','p_smap','p_eco','p_modis'],soon=['p_gaez']
  return <>
    <header><a className="brand" href="#home" onClick={e=>go(e,'home')}>{t.app}</a>
      <nav aria-label="Main">{nav.map(([k,l])=><a key={k} href={'#'+k} onClick={e=>go(e,k)} aria-current={route===k?'page':undefined}>{l}</a>)}</nav>
      <div className="langs"><button className="tbtn" aria-label={t.theme} title={t.theme} onClick={()=>setTheme(theme==="dark"?"light":"dark")}>{theme==="dark"?"☀":"☾"}</button><select aria-label={t.lang} value={lang} onChange={e=>changeLang(e.target.value)}>{LANGS.map(([k,n])=><option key={k} value={k}>{n}</option>)}</select>
      {DIA[lang]&&<select aria-label={t.dia} value={dia} onChange={e=>changeLang(null,e.target.value)}>{Object.entries(DIA[lang]).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select>}</div>
    </header>
    <main key={route} className="route">
      {route==='tool'?<Tool t={t} lang={lang} dia={dia}/>:route==='method'?
        <div className="page"><h1>{t.how}</h1><ul className="plist">
          {live.map(k=><li key={k}><span className="pill on">{t.live}</span>{t[k]}</li>)}
          {soon.map(k=><li key={k}><span className="pill">{t.soon}</span>{t[k]}</li>)}</ul><p>{t.mth}</p><h2>{t.gl}</h2><dl>{t.glossary.map(([a,b])=><div key={a}><dt><b>{a}</b></dt><dd>{b}</dd></div>)}</dl></div>
      :<Home t={t} go={go}/>}
    </main>
    <footer>FieldX · NASA POWER · NASA GIBS · ERA5 · SRTM · OpenStreetMap · Open-Meteo</footer>
    <Chat lang={lang} dia={dia} route={route}/></>
}
