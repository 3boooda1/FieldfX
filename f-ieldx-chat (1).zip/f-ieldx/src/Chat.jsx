import {useEffect,useRef,useState} from 'react'
import {getFx,subFx} from './ctx.js'
import {VOICE} from './data.js'

const S={
en:{open:'Ask AI',title:'FieldX Advisor',ph:'Ask about your land…',send:'Send',clear:'New chat',close:'Close',mic:'Speak',listen:'Listen',
  hello:'Hi! I am the FieldX advisor. I answer from the NASA data of the land you selected, compare rotations, and talk through options with you.',
  none:'No land selected yet. Open the Tool, pick a place (or draw your field), then ask me anything.',noland:'No land selected',ha:'ha',ready:'data loaded',notyet:'not analyzed yet',
  reading:'Reading NASA data for this land…',err:'Could not reach the advisor. Please try again.',
  q:['Is this land good for wheat?','Do I have a water problem?','What are the main risks here?','Explain the results simply','Which rotation would you pick and why?']},
ar:{open:'اسأل الذكاء الاصطناعي',title:'مستشار FieldX',ph:'اسأل عن أرضك…',send:'إرسال',clear:'محادثة جديدة',close:'إغلاق',mic:'تكلم',listen:'استمع',
  hello:'أهلاً! أنا مستشار FieldX. بجاوبك من بيانات ناسا الخاصة بالأرض اللي اخترتها، وأقارن الدورات الزراعية وأتناقش معاك في الخيارات.',
  none:'لسه مفيش أرض متحددة. افتح الأداة، اختار مكان (أو ارسم حدود أرضك)، وبعدها اسألني عن أي حاجة.',noland:'مفيش أرض متحددة',ha:'هكتار',ready:'البيانات جاهزة',notyet:'لسه متحللتش',
  reading:'بقرأ بيانات ناسا للأرض دي…',err:'مقدرتش أوصل للمستشار. حاول تاني.',
  q:['الأرض دي تنفع قمح؟','عندي مشكلة مياه؟','إيه أهم المخاطر هنا؟','فسرلي النتايج ببساطة','أنهي دورة زراعية تختارها ولي؟']}}

const waitFx=(p,ms)=>new Promise(ok=>{let u;const fin=()=>{clearTimeout(t);u&&u();ok(getFx())},t=setTimeout(fin,ms);u=subFx(()=>{if(p(getFx()))fin()});if(p(getFx()))fin()})
const inl=t=>t.split(/(\*\*[^*]+\*\*)/g).map((p,i)=>p.length>4&&p.startsWith('**')&&p.endsWith('**')?<b key={i}>{p.slice(2,-2)}</b>:p)
function Md({text}){const out=[];let li=[];const fl=()=>{if(li.length){out.push(<ul key={'u'+out.length}>{li}</ul>);li=[]}}
  text.split('\n').forEach((l,i)=>{const m=/^\s*(?:[-*•]|\d+[.)])\s+(.*)/.exec(l);if(m){li.push(<li key={i}>{inl(m[1])}</li>);return}
    fl();if(!l.trim())return;const h=/^#{1,4}\s+(.*)/.exec(l);out.push(<p key={'p'+i}>{h?<b>{h[1]}</b>:inl(l)}</p>)});fl();return <>{out}</>}

export default function Chat({lang,dia,route}){
  const s=S[lang]||S.en,[open,setOpen]=useState(false),[msgs,setMsgs]=useState([]),[q,setQ]=useState(''),[busy,setBusy]=useState(false),[status,setStatus]=useState(''),[fx,setFx]=useState(getFx()),[lis,setLis]=useState(false)
  const list=useRef(),rec=useRef(),SR=typeof window!=='undefined'&&(window.SpeechRecognition||window.webkitSpeechRecognition)
  useEffect(()=>subFx(()=>setFx(getFx())),[])
  useEffect(()=>{const e=list.current;if(e)e.scrollTop=e.scrollHeight},[msgs,status,open])
  const send=async text=>{
    text=(text??q).trim();if(!text||busy)return
    setQ('');setBusy(true)
    const hist=[...msgs.filter(m=>!m.err&&m.content),{role:'user',content:text}]
    setMsgs([...msgs,{role:'user',content:text},{role:'assistant',content:''}])
    try{
      let f=getFx()
      if(f&&!f.climate&&f.canAnalyze){setStatus(s.reading);let cl=null;try{cl=await f.analyze()}catch{};if(cl)f=await waitFx(x=>x&&x.climate&&x.plans,2500)}
      setStatus('')
      const ctx=f?(({analyze,canAnalyze,...r})=>r)(f):null
      const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:hist,context:ctx,lang,dia,route})})
      if(!r.ok||!r.body)throw new Error('http '+r.status)
      const rd=r.body.getReader(),dec=new TextDecoder();let acc=''
      for(;;){const {done,value}=await rd.read();if(done)break;acc+=dec.decode(value,{stream:true});const a=acc;setMsgs(m=>[...m.slice(0,-1),{role:'assistant',content:a}])}
      if(!acc.trim())throw new Error('empty')
    }catch{setMsgs(m=>[...m.slice(0,-1),{role:'assistant',content:s.err,err:true}])}
    finally{setBusy(false);setStatus('')}
  }
  const mic=()=>{if(!SR)return;if(lis){rec.current&&rec.current.stop();return}
    const r=new SR();r.lang=VOICE[dia]||VOICE[lang]||'en-US';r.interimResults=false
    r.onresult=e=>setQ(v=>(v+' '+e.results[0][0].transcript).trim());r.onend=()=>setLis(false);r.onerror=()=>setLis(false)
    rec.current=r;setLis(true);r.start()}
  const speak=t=>{if(!window.speechSynthesis)return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t.replace(/\*\*/g,''));u.lang=VOICE[dia]||VOICE[lang]||'en-US';speechSynthesis.speak(u)}
  const chip=fx?`${fx.place.name}${fx.areaHa?' · '+fx.areaHa+' '+s.ha:''} · ${fx.climate?s.ready:s.notyet}`:s.noland
  return <>
    {!open&&<button className="cfab" onClick={()=>setOpen(true)} aria-label={s.open} title={s.open}>
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/><path d="M9 12.5c1.5 1.8 4.5 1.8 6 0"/></svg><span>{s.open}</span></button>}
    {open&&<section className="chat" role="dialog" aria-label={s.title}>
      <div className="chead"><div><b>{s.title}</b><small>{chip}</small></div>
        <div><button className="link" onClick={()=>{if(!busy)setMsgs([])}}>{s.clear}</button><button className="cx" onClick={()=>setOpen(false)} aria-label={s.close}>×</button></div></div>
      <div className="cbody" ref={list} data-lenis-prevent="true" aria-live="polite">
        <div className="cm a"><Md text={s.hello}/>{!fx&&<p className="small">{s.none}</p>}</div>
        {msgs.map((m,i)=><div key={i} className={'cm '+(m.role==='user'?'u':m.err?'e':'a')} dir="auto">
          {m.content?<Md text={m.content}/>:<p className="small">…</p>}
          {m.role==='assistant'&&m.content&&!m.err&&!busy&&<button className="link" onClick={()=>speak(m.content)}>🔊 {s.listen}</button>}</div>)}
        {status&&<p className="small">{status}</p>}
      </div>
      {!msgs.length&&<div className="cq">{s.q.map(x=><button key={x} onClick={()=>send(x)}>{x}</button>)}</div>}
      <div className="cin">
        <textarea rows="1" dir="auto" value={q} placeholder={s.ph} aria-label={s.ph} onChange={e=>setQ(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.nativeEvent.isComposing){e.preventDefault();send()}}}/>
        {SR&&<button className="mic" aria-pressed={lis} aria-label={s.mic} title={s.mic} onClick={mic}>🎤</button>}
        <button onClick={()=>send()} disabled={busy||!q.trim()} aria-label={s.send}>➤</button>
      </div>
    </section>}
  </>
}
