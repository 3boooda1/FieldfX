import {createRoot} from 'react-dom/client'
import App from './App.jsx'
import {initFx} from './fx.jsx'
import './styles.css'
initFx()
createRoot(document.getElementById('root')).render(<App/>)
