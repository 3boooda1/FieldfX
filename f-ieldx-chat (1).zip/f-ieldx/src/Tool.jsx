import {useEffect,useRef,useState} from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import {CROPS,DS,VOICE,fill,note_ar,T} from './data.js'
import {getPoints,geocode,boundary} from './nasa.js'
import {planAll,simulate} from './plan.js'
import {compare} from './engine.js'
import {Ring,Num,vt,calm} from './fx.jsx'
import {setFx} from './ctx.js'

function Search({t,lang,onPick}){
  const [q,setQ]=useState(''),[o,setO]=useState([]),[b,setB]=useState(false),[d,setD]=useState(false)
  useEffect(()=>{if(q.trim().length<2){setO([]);setD(false);return}
    const id=setTimeout(async()=>{setB(true);try{setO(await geocode(q,lang))}catch{setO([])}setB(false);setD(true)},300);return()=>clearTimeout(id)},[q,lang])
  return <div className="search"><label><h2>{t.where}</h2><input type="search" autoComplete="off" value={q} onChange={e=>setQ(e.target.value)} placeholder={t.ph} autoFocus enterKeyHint="search"/></label>
    <ul>{o.map((x,i)=><li key={i} style={{'--i':i}}><button onClick={()=>onPick(x)}>{x.name}</button></li>)}</ul>
    {b&&<p className="small">{t.searching}</p>}{d&&!b&&!o.length&&<p className="small">{t.none}</p>}</div>
}

const grid=(a,o)=>{const d=[-.2,0,.2],r=[];d.forEach(x=>d.forEach(y=>r.push([a+x,o+y])));return [[a,o],...r.filter((_,i)=>i!==4)]}
const pts=p=>[cen(p),...p.slice(0,5)]
const cen=p=>[p.reduce((s,x)=>s+x[0],0)/p.length,p.reduce((s,x)=>s+x[1],0)/p.length]
const ha=p=>{const [a0,o0]=cen(p),P=p.map(([a,o])=>[(o-o0)*111320*Math.cos(a0*Math.PI/180),(a-a0)*110574]);let s=0;P.forEach((q,i)=>{const n=P[(i+1)%P.length];s+=q[0]*n[1]-n[0]*q[1]});return Math.abs(s)/2/1e4}
function MapPick({center,code,mode,poly,onPick,flyAt=0}){
  const el=useRef(),r=useRef({}),[bd,setBd]=useState(null)
  r.current.mode=mode
  useEffect(()=>{
    const m=L.map(el.current,{worldCopyJump:true}).setView(center,4);r.current.m=m
    const osm=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'© OpenStreetMap'})
    const d=new Date(Date.now()-3*864e5).toISOString().slice(0,10),d8=new Date(Date.now()-8*864e5).toISOString().slice(0,10)
    const G=(id,lv,day)=>L.tileLayer(`https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/${id}/default/${day}/GoogleMapsCompatible_Level${lv}/{z}/{y}/{x}.png`,{maxNativeZoom:lv,maxZoom:18,opacity:.75,attribution:'NASA GIBS'})
    const tc=L.tileLayer(`https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Terra_CorrectedReflectance_TrueColor/default/${d}/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg`,{maxNativeZoom:9,maxZoom:18,attribution:'NASA GIBS'})
    const sat=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',{maxZoom:19,attribution:'Esri'}).addTo(m)
    const lab=L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',{maxZoom:19}).addTo(m)
    L.control.layers({'Map':osm,'Satellite':sat,'NASA MODIS':tc},{'Labels':lab,'NASA NDVI':G('MODIS_Terra_NDVI_8Day',9,d8),'NASA rain (IMERG)':G('IMERG_Precipitation_Rate',6,d8),'NASA land temp':G('MODIS_Terra_Land_Surface_Temp_Day',7,d8)},{collapsed:false}).addTo(m)
    m.on('click',e=>{if(r.current.mode!=='poly')return;onPick(e.latlng.lat,((e.latlng.lng+540)%360)-180)})
    const sty={color:'#c9a227',weight:3,fillColor:'#c9a227',fillOpacity:.07,lineJoin:'round'},c=r.current;let alive=true
    const fit=()=>{const lay=c.lay,rtl=document.documentElement.dir==='rtl',wide=innerWidth>900,pad=wide?500:20
      if(lay)m.flyToBounds(lay.getBounds(),{duration:2.4,maxZoom:11,paddingTopLeft:[wide&&!rtl?pad:30,30],paddingBottomRight:[wide&&rtl?pad:30,wide?30:Math.round(innerHeight*.55)]})
      else m.flyTo(center,9,{duration:2.4})}
    const arrive=b=>{if(!alive||c.done)return;c.done=true
      c.lay=b&&b.geo?L.geoJSON(b.geo,{style:()=>sty}):L.rectangle([[center[0]-.2,center[1]-.2],[center[0]+.2,center[1]+.2]],sty)
      setBd(c.lay);if(c.ready)fit()}
    Promise.race([boundary(center[0],center[1],code),new Promise((_,j)=>setTimeout(j,6000))]).then(arrive,()=>arrive(null))
    const fid=setTimeout(()=>{c.ready=true;if(c.done)fit()},flyAt)
    return()=>{alive=false;clearTimeout(fid);m.remove()}
  },[])
  useEffect(()=>{const c=r.current;c.pg?.remove();if(mode!=='poly'||!poly.length)return;const g=L.layerGroup().addTo(c.m);if(poly.length>2)L.polygon(poly,{color:'#c9a227',weight:3,fillOpacity:.28}).addTo(g);else if(poly.length>1)L.polyline(poly,{color:'#c9a227',weight:3}).addTo(g);poly.forEach(p=>L.circleMarker(p,{radius:7,color:'#fff',weight:2,fillColor:'#c9a227',fillOpacity:1}).addTo(g));c.pg=g},[poly,mode])
  useEffect(()=>{if(!bd)return;const c=r.current;if(mode==='area')bd.addTo(c.m);else bd.remove();return()=>{bd.remove()}},[bd,mode])
  return <div id="map" data-lenis-prevent="true" ref={el} role="application" aria-label="Map"/>
}

function Explorer({place,t,lang,dia,onChange,lead=0}){
  const [view,setView]=useState('f'),[mode,setMode]=useState('area'),[poly,setPoly]=useState([]),[c1,setC1]=useState('wheat'),[c2,setC2]=useState('maize')
  const [pr,setPr]=useState({water:2,soil:2,climate:1,market:1,ops:1}),[cfg,setCfg]=useState({tex:'loam',irr:0,om:'',ph:'',ec:''}),[sim,setSim]=useState({rain:0,temp:0}),[st,setSt]=useState('idle'),[res,setRes]=useState(null)
  const li=Math.max(0,['en','ar','fr'].indexOf(lang)),name=k=>CROPS[k].n[li]
  const run=async()=>{setSt('load');try{const cl=await getPoints(mode==='area'?grid(place.lat,place.lon):pts(poly));setRes({cl});setSt('ok');return cl}catch(e){setSt('err');return null}}
  const list=res?planAll([c1,c2],simulate(res.cl,sim),pr,cfg,place.lat<0):null,base=res&&(sim.rain||sim.temp)?planAll([c1,c2],res.cl,pr,cfg,place.lat<0):null,best=res&&[...list].sort((x,y)=>y.total-x.total)[0]
  const summ=()=>{const d=lang==='ar'?DS.egy:t;return fill(d.best,{a:name(best.ids[0]),b:name(best.ids[1]),s:best.total})+' '+fill(d.rainS,{r:Math.round(res.cl.rain)})}
  const listen=()=>{if(!window.speechSynthesis)return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(summ());u.lang=VOICE[dia]||VOICE[lang];speechSynthesis.speak(u)}
  const lv=v=>v>=70?['good',t.good]:v>=45?['mid',t.mid]:['low',t.low]
  const seg=(items,v,fn)=><div className="seg" role="group">{items.map(([k,l])=><button key={k} aria-pressed={v===k} onClick={()=>fn(k)}>{l}</button>)}</div>
  const max=res?Math.max(...res.cl.monthly):1
  const Sum=()=><div className="sum"><Ring v={best.total}/><div><p>{summ()}</p><div className="acts"><button className="btn" onClick={listen}>{t.listen}</button><button className="btn" onClick={()=>print()}>{t.print}</button></div></div></div>
  const runRef=useRef();runRef.current=run
  useEffect(()=>{ // publish the selected land + results for the AI chat widget
    const g=mode==='poly'&&poly.length>2,c=mode==='poly'&&poly.length?cen(poly):[place.lat,place.lon],rd=v=>+v.toFixed(5)
    setFx({place:{name:place.name,lat:place.lat,lon:place.lon},
      selection:mode==='area'?'whole place (9 climate sample points within about 0.2 degrees of the place centre)':'field polygon drawn by the user',
      polygon:mode==='poly'?poly.map(p=>[rd(p[0]),rd(p[1])]):undefined,areaHa:g?+ha(poly).toFixed(1):undefined,centre:c.map(rd),southernHemisphere:place.lat<0,
      crops:{first:{id:c1,name:name(c1)},second:{id:c2,name:name(c2)}},
      soilInputs:{texture:cfg.tex,irrigation:t['irr'+cfg.irr],organicMatterPct:cfg.om||null,pH:cfg.ph||null,ecDsPerM:cfg.ec||null},
      priorities:pr,scenario:{rainChangePct:sim.rain,warmingC:sim.temp},view:view==='f'?'farmer summary':'engineer details',
      climate:res?res.cl:null,
      plans:res?list.map(s=>({strategy:t[s.k],crops:s.seq.map(name),fit:s.total,water:s.water,climate:s.climate,soil:s.soil,market:s.mkt,operations:s.ops,confidence:s.conf,
        reasons:s.why.map(k=>t[k]||k),evidence:s.ev.map(([k,o,src])=>fill(t[k],o)+' ['+src+']'),risks:s.flags.map(([k,o])=>fill(t[k],o)),benefits:s.ben.map(k=>t[k]||k),
        calendar:s.cal.map(r=>r.join('')),organicMatterTrendPctPerYear:+s.om.toFixed(2),usedLabValues:s.labs})):null,
      best:best?{crops:best.ids.map(name),fit:best.total}:null,
      canAnalyze:mode==='area'||poly.length>2,analyze:()=>runRef.current()})
  },[place,mode,poly,c1,c2,pr,cfg,sim,res,view,lang,dia])
  useEffect(()=>()=>setFx(null),[])
  return <div className="work pop" style={{'--wd':lead+'s'}}>
    <MapPick code={place.code} flyAt={Math.round(lead*1000)+200} center={[place.lat,place.lon]} mode={mode} poly={poly} onPick={(a,b)=>{setPoly(p=>[...p,[a,b]]);setRes(null);setSt('idle')}}/>
    <div className="panel glass" data-lenis-prevent="true" aria-live="polite">
      <div className="top"><b>{place.name}</b><button className="link" onClick={onChange}>{t.change}</button></div>
      {seg([['f',t.v_f],['e',t.v_e]],view,setView)}
      {seg([['area',t.m_area],['poly',t.m_pin]],mode,k=>{setMode(k);setRes(null);setSt('idle')})}
      <p className="small">{mode==='area'?t.h_area:(poly.length>2?`${ha(poly).toFixed(1)} ha · ${poly.length} ${t.pts}`:t.h_pin)}</p>
      {mode==='poly'&&<div className="acts"><button className="link" onClick={()=>{setPoly(p=>p.slice(0,-1));setRes(null)}}>{t.undo}</button><button className="link" onClick={()=>{setPoly([]);setRes(null)}}>{t.clear}</button></div>}
      <div className="two">{[[t.c1,c1,setC1],[t.c2,c2,setC2]].map(([lb,v,fn])=><label key={lb}>{lb}<select value={v} onChange={e=>fn(e.target.value)}>{Object.keys(CROPS).map(k=><option key={k} value={k}>{name(k)}</option>)}</select></label>)}</div>
      <div className="two">{[[t.tex,'tex',[['sand',t.sand],['loam',t.loam],['clay',t.clay]]],[t.irr,'irr',[[0,t.irr0],[1,t.irr1],[2,t.irr2]]]].map(([lb,k,o])=><label key={k}>{lb}<select value={cfg[k]} onChange={e=>{setCfg({...cfg,[k]:k==='irr'?+e.target.value:e.target.value});setRes(null);setSt('idle')}}>{o.map(([v,n])=><option key={v} value={v}>{n}</option>)}</select></label>)}</div>
      <fieldset className="lab"><legend>{t.lab}</legend>{[['om',t.lab_om,0.1],['ph',t.lab_ph,0.1],['ec',t.lab_ec,0.1]].map(([k,lb,st])=><label key={k}>{lb}<input type="number" inputMode="decimal" step={st} min="0" value={cfg[k]} placeholder="—" onChange={e=>setCfg({...cfg,[k]:e.target.value})}/></label>)}</fieldset>
      <fieldset style={{border:0,padding:0,margin:0,display:'grid',gap:6}}><legend>{t.pri}</legend>
        {[['water',t.pw],['soil',t.ps],['climate',t.pc],['market',t.pm],['ops',t.po]].map(([k,lb])=><label key={k}>{lb}<input type="range" min="0" max="3" value={pr[k]} onChange={e=>setPr({...pr,[k]:+e.target.value})}/></label>)}</fieldset>
      <button className="btn go" disabled={(mode==='poly'&&poly.length<3)||st==='load'} onClick={run}>{st==='load'?t.load:t.go}</button>
      {st==='err'&&<p className="err" role="alert">{t.err}</p>}
      {res&&<fieldset className="sim"><legend>{t.sim}</legend><label>{t.sim_rain}: {sim.rain>0?'+':''}{sim.rain}%<input type="range" min="-40" max="30" step="5" value={sim.rain} onChange={e=>setSim({...sim,rain:+e.target.value})}/></label><label>{t.sim_temp}: +{sim.temp}°C<input type="range" min="0" max="4" step="0.5" value={sim.temp} onChange={e=>setSim({...sim,temp:+e.target.value})}/></label></fieldset>}
      {res&&view==='f'&&<div className="stag">{Sum()}
        {[['water',t.k_water,t.q_water],['climate',t.k_weather,t.q_weather],['soil',t.k_soil,t.q_soil]].map(([k,a,q],i)=>{const[c,w]=lv(best[k]);return <div className={'chk '+c} style={{'--i':i}} key={k}><span className="dot"/><div><b>{a}</b><small>{q}</small></div><em>{w}</em></div>})}
        <h3>{t.do_title}</h3><ol className="steps"><li>{fill(t.do1,{a:name(best.ids[0]),b:name(best.ids[1])})}</li><li>{best.water<60?t.do2w:t.do2}</li><li>{t.do3}</li></ol>
        <h3>{t.s_all}</h3>{list.map((s,i)=><div className="chk" style={{'--i':i}} key={s.k}><span className={'dot '+lv(s.total)[0]}/><div><b>{t[s.k]}</b><small>{s.seq.map(name).join(' → ')}{s.ben[0]&&' · '+t[s.ben[0]]}</small></div><em>{lv(s.total)[1]}{base&&(()=>{const d=s.total-base[i].total;return d?` ${d>0?'+':''}${d}`:''})()}</em></div>)}
        <p className="small">{lang==='ar'?note_ar.egy:(t.note||T.en.note)}</p></div>}
      {res&&view==='e'&&<div className="stag eng">{Sum()}
        <h3>{t.tech}</h3>
        <table><tbody>
          <tr><th>{t.rain}</th><td><Num v={res.cl.rain}/> mm{res.cl.rainMin!=null&&` (${t.range} ${Math.round(res.cl.rainMin)}–${Math.round(res.cl.rainMax)})`}</td></tr>
          <tr><th>{t.tmax}</th><td><Num v={res.cl.tmax} d={1}/> °C</td></tr><tr><th>{t.tmin}</th><td><Num v={res.cl.tmin} d={1}/> °C</td></tr><tr><th>{t.dry}</th><td><Num v={res.cl.dry}/></td></tr>
          {res.cl.et0!=null&&<tr><th>{t.et0}</th><td><Num v={res.cl.et0}/> mm</td></tr>}
          {res.cl.frostDays!=null&&<tr><th>{t.frostd}</th><td><Num v={res.cl.frostDays} d={1}/></td></tr>}
          {res.cl.hotDays!=null&&<tr><th>{t.hotd}</th><td><Num v={res.cl.hotDays} d={1}/></td></tr>}
          {res.cl.heavy!=null&&<tr><th>{t.heavyd}</th><td><Num v={res.cl.heavy} d={1}/></td></tr>}
          {res.cl.maxDay!=null&&<tr><th>{t.maxd}</th><td><Num v={res.cl.maxDay}/> mm</td></tr>}
          {res.cl.trendRain!=null&&<tr><th>{t.trendR}</th><td>{res.cl.trendRain>0?'+':''}<Num v={res.cl.trendRain}/> mm</td></tr>}
          {res.cl.trendTemp!=null&&<tr><th>{t.trendT}</th><td>{res.cl.trendTemp>0?'+':''}<Num v={res.cl.trendTemp} d={2}/> °C</td></tr>}
          {res.cl.eco&&<tr><th>{t.eco}</th><td><Num v={res.cl.eco.mean} d={1}/> °C ({res.cl.eco.min.toFixed(0)}–{res.cl.eco.max.toFixed(0)}, {res.cl.eco.n})</td></tr>}
          {res.cl.hls&&<tr><th>{t.hls}</th><td><Num v={res.cl.hls.mean} d={2}/> ({res.cl.hls.min.toFixed(2)}–{res.cl.hls.max.toFixed(2)}, {res.cl.hls.n})</td></tr>}
          {res.cl.smap&&<tr><th>{t.smap}</th><td><Num v={res.cl.smap.mean} d={3}/> m³/m³ ({res.cl.smap.min.toFixed(2)}–{res.cl.smap.max.toFixed(2)}, {res.cl.smap.n})</td></tr>}
          {res.cl.soilRoot!=null&&<tr><th>{t.soilW}</th><td><Num v={res.cl.soilRoot} d={2}/></td></tr>}
          {res.cl.elev!=null&&<tr><th>{t.elev}</th><td><Num v={res.cl.elev}/> m</td></tr>}
          {res.cl.slope!=null&&<tr><th>{t.slope}</th><td><Num v={res.cl.slope} d={1}/> %</td></tr>}
          <tr><th>{t.conf}</th><td>{t['conf_'+res.cl.conf]}</td></tr>
          <tr><th>{t.samples}</th><td>{res.cl.n||1} · {(mode==='area'?[place.lat,place.lon]:cen(poly)).map(v=>v.toFixed(3)).join(', ')}</td></tr>
          {mode==='poly'&&<tr><th>{t.area}</th><td>{ha(poly).toFixed(1)} ha</td></tr>}
          <tr><th>{t.weights}</th><td>{t.sub_w} {pr.water} · {t.sub_s} {pr.soil} · {t.sub_c} {pr.climate}</td></tr></tbody></table>
        <div><div className="bars" role="img" aria-label={t.months}>{res.cl.monthly.map((v,i)=><i key={i} style={{height:`${v/max*100}%`,'--i':i}} title={`${i+1}: ${Math.round(v)} mm`}/>)}</div>
          <div className="mrow">{res.cl.monthly.map((v,i)=><span key={i}>{Math.round(v)}</span>)}</div><span className="small">{t.months}</span></div>{res.cl.ndvi&&<div><div className="bars ndv" role="img" aria-label={t.ndvi_t}>{res.cl.ndvi.map((v,i)=><i key={i} style={{height:`${Math.max(0,v||0)*100}%`,'--i':i}} title={`${i+1}: ${v==null?'—':v.toFixed(2)}`}/>)}</div><span className="small">{t.ndvi_t}</span></div>}{res.cl.yearT&&<Spark v={res.cl.yearT} label={t.trendY}/>}
        {list.map((s,i)=><section className="strat" style={{'--i':i}} key={s.k}><h3>{t[s.k]}<Ring v={s.total} size={52}/></h3><div className="crops">{s.seq.map((c,y)=><span className="yr" key={y}><em>{t.yr} {y+1}</em>{name(c)}</span>)}</div>
          {[['sub_w','water'],['sub_c','climate'],['sub_s','soil'],['sub_m','mkt'],['sub_o','ops']].map(([a,k])=><div className="sub" key={k}><span>{t[a]}</span><div><i style={{width:s[k]+'%'}}/></div><b>{s[k]}</b></div>)}
          <h4>{t.why}</h4><ul>{s.why.map(k=><li key={k}>{t[k]}</li>)}</ul><h4>{t.evid}</h4><ul>{s.ev.map(([k,o,src],j)=><li key={j}>{fill(t[k],o)} <small>· {src}</small></li>)}</ul><Cal s={s} t={t}/><p className="small">{t.omt}: {s.om>0?'+':''}{s.om.toFixed(2)} %/yr · {t.conf}: {t['conf_'+s.conf]}</p>
          <h4>{t.ben}</h4><ul>{s.ben.length?s.ben.map(k=><li key={k}>{t[k]}</li>):<li>—</li>}</ul><h4>{t.rk}</h4><ul>{s.flags.map(([k,o])=><li key={k}>{fill(t[k],o)}</li>)}</ul><h4>{t.gp}</h4><ul>{!s.labs&&<li>{t.gap_soil}</li>}<li>{t.gap_nasa}</li><li>{t.m_soil}</li></ul></section>)}
        <p className="small">{t.formula}</p><p className="small">{t.res_note}</p><p className="small">{t.gap}</p></div>}
    </div></div>
}

function Cal({s,t}){return <div className="cal" role="img" aria-label={t.cal}><h4>{t.cal}</h4>{s.cal.map((row,y)=><div className="cy" key={y}><b>{y+1}</b>{row.map((c,m)=><i key={m} className={'m'+c} title={m+1}/>)}</div>)}<div className="small lg"><i className="mc"/> {t.cal_c} <i className="mb"/> {t.cal_b} <i className="mv"/> {t.cal_v}</div></div>}
function Spark({v,label}){const mn=Math.min(...v),mx=Math.max(...v),w=300,h=70,P=v.map((x,i)=>`${i/(v.length-1)*w},${h-6-(x-mn)/((mx-mn)||1)*(h-12)}`).join(' ')
  return <div className="spark"><svg viewBox={`0 0 ${w} ${h}`} role="img" aria-label={label}><polyline points={P}/></svg><div className="mrow"><span>2005</span><span>{mn.toFixed(1)}–{mx.toFixed(1)}°C</span><span>2024</span></div><span className="small">{label}</span></div>}
const ZS=3,ZE=8,ZR=2 // zoom.mp4 segment (seconds) and playback rate
export default function Tool({t,lang,dia}){
  const [place,setPlace]=useState(null),[stage,setStage]=useState('search'),[rect,setRect]=useState(null),[zon,setZon]=useState(false),[out,setOut]=useState(false)
  const box=useRef(),zv=useRef(),lead=useRef(0)
  const pick=p=>{
    setPlace(p)
    if(calm()){lead.current=0;setStage('map');return}
    const r=box.current.getBoundingClientRect()
    lead.current=(ZE-ZS)/ZR+.2;setRect({top:r.top,height:r.height});setStage('dive')
  }
  const reset=()=>{setStage('search');setPlace(null);setRect(null);setZon(false);setOut(false)}
  useEffect(()=>{
    if(stage!=='dive')return
    const z=zv.current;let dead=false,done=false,id,t1,t2
    const fin=()=>{if(dead||done)return;done=true;clearInterval(id);clearTimeout(t1);setOut(true);t2=setTimeout(()=>{if(!dead)setStage('map')},950)}
    const go=()=>{z.currentTime=ZS;z.playbackRate=ZR;z.play().then(()=>{if(!dead)setZon(true)}).catch(fin)}
    z.readyState>0?go():z.addEventListener('loadedmetadata',go,{once:true})
    id=setInterval(()=>{if(z.currentTime>=ZE)fin()},80);t1=setTimeout(fin,7000)
    return()=>{dead=true;clearInterval(id);clearTimeout(t1);clearTimeout(t2)}
  },[stage])
  const diving=stage==='dive'
  return <>
    {stage!=='search'&&<Explorer place={place} t={t} lang={lang} dia={dia} onChange={reset} lead={lead.current}/>}
    {stage!=='map'&&<div ref={box} className={'stage'+(diving?' dive':'')+(out?' out':'')} style={diving&&rect?{position:'fixed',top:rect.top,left:0,width:'100vw',height:rect.height,minHeight:0,margin:0,zIndex:900}:undefined}>
      <video className="bgv" src="/globe.mp4" poster="/globe.jpg" autoPlay muted loop playsInline preload="auto" aria-hidden="true"/><div className="shade"/>
      <video ref={zv} className={'zv'+(zon?' on':'')} src="/zoom.mp4" muted playsInline preload="auto" aria-hidden="true"/>
      <Search t={t} lang={lang} onPick={pick}/></div>}
  </>
}
